// ================================================================
//  AUTENTICAÇÃO - geração/validação de token (JWT)
// ================================================================

const jwt = require('jsonwebtoken');

// Em produção, defina a variável de ambiente JWT_SECRET com um valor
// forte e secreto. Este fallback é só para rodar localmente.
const JWT_SECRET = process.env.JWT_SECRET || 'troque-este-segredo-em-producao';
const TOKEN_EXPIRES_IN = '7d';

function generateToken(user) {
    return jwt.sign(
        { sub: user.id, email: user.email, name: user.name },
        JWT_SECRET,
        { expiresIn: TOKEN_EXPIRES_IN }
    );
}

// Middleware: exige um token válido no header Authorization: Bearer <token>
function requireAuth(req, res, next) {
    const header = req.headers.authorization || '';
    const [scheme, token] = header.split(' ');

    if (scheme !== 'Bearer' || !token) {
        return res.status(401).json({ error: 'Não autenticado. Faça login novamente.' });
    }

    try {
        const payload = jwt.verify(token, JWT_SECRET);
        req.user = { id: payload.sub, email: payload.email, name: payload.name };
        next();
    } catch (err) {
        return res.status(401).json({ error: 'Token inválido ou expirado. Faça login novamente.' });
    }
}

module.exports = { generateToken, requireAuth };
