// ================================================================
//  CONEXÃO COM O BANCO DE DADOS (SQLite)
//  Banco de dados real em arquivo, persistente em disco.
// ================================================================

const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = path.join(__dirname, '..', 'data', 'assembler.db');

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

// Schema único para todas as categorias de peça.
// Colunas específicas de cada categoria (socket, chipset, wattage, etc.)
// ficam guardadas em `extra` como JSON, já que cada categoria tem campos
// diferentes — isso evita 5 tabelas quase idênticas e mantém a API simples.
db.exec(`
    CREATE TABLE IF NOT EXISTS parts (
        id         TEXT PRIMARY KEY,
        category   TEXT NOT NULL,
        name       TEXT NOT NULL,
        price      REAL NOT NULL,
        extra      TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_parts_category ON parts(category);

    -- Usuários cadastrados. Senha nunca é salva em texto puro,
    -- só o hash (bcrypt).
    CREATE TABLE IF NOT EXISTS users (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        name          TEXT NOT NULL,
        email         TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        lgpd_consent  INTEGER NOT NULL DEFAULT 0,
        consent_at    TEXT,
        created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- PCs salvos por cada usuário.
    CREATE TABLE IF NOT EXISTS builds (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        label        TEXT NOT NULL,
        budget       REAL NOT NULL,
        purpose      TEXT,
        total        REAL NOT NULL,
        components   TEXT NOT NULL DEFAULT '{}',
        created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_builds_user ON builds(user_id);
`);

module.exports = db;
