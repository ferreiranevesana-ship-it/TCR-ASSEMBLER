// ================================================================
//  SEED - Popula o banco de dados a partir do database.js original
//  Rode com: npm run seed
// ================================================================

const fs = require('fs');
const path = require('path');
const db = require('./db');

// database.js original foi escrito para rodar no browser (window.DATABASE).
// Para reaproveitar os dados sem reescrever tudo à mão, criamos um `window`
// falso, avaliamos o arquivo original e lemos o resultado.
const originalPath = path.join(__dirname, 'original_database.js');
const code = fs.readFileSync(originalPath, 'utf8');
const fakeWindow = {};
// eslint-disable-next-line no-new-func
new Function('window', code)(fakeWindow);
const DATABASE = fakeWindow.DATABASE;

if (!DATABASE) {
    console.error('Não foi possível carregar original_database.js');
    process.exit(1);
}

const insert = db.prepare(`
    INSERT INTO parts (id, category, name, price, extra)
    VALUES (@id, @category, @name, @price, @extra)
    ON CONFLICT(id) DO UPDATE SET
        category = excluded.category,
        name = excluded.name,
        price = excluded.price,
        extra = excluded.extra,
        updated_at = datetime('now')
`);

const insertAll = db.transaction((categories) => {
    let count = 0;
    for (const [category, items] of Object.entries(categories)) {
        for (const item of items) {
            const { id, name, price, ...rest } = item;
            insert.run({
                id,
                category,
                name,
                price,
                extra: JSON.stringify(rest),
            });
            count++;
        }
    }
    return count;
});

const total = insertAll(DATABASE);
console.log(`Seed concluído: ${total} peças gravadas em data/assembler.db`);
