// ================================================================
//  SERVIDOR - API REST do TCR_ASSEMBLER
// ================================================================

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const db = require('./db');
const { generateToken, requireAuth } = require('./auth');

const app = express();
app.use(cors());
app.use(express.json());

const CATEGORIES = ['cpu', 'gpu', 'placa_mae', 'ram', 'psu'];

function rowToPart(row) {
    return {
        id: row.id,
        name: row.name,
        price: row.price,
        ...JSON.parse(row.extra),
    };
}

// GET /api/health - checagem simples de saúde da API
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
});

// ================================================================
//  AUTENTICAÇÃO - registro, login e dados do usuário logado
// ================================================================

// POST /api/auth/register - cria uma conta nova
app.post('/api/auth/register', (req, res) => {
    const { name, email, password, lgpdConsent } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ error: 'Preencha nome, email e senha.' });
    }
    if (password.length < 6) {
        return res.status(400).json({ error: 'A senha precisa ter pelo menos 6 caracteres.' });
    }
    if (!lgpdConsent) {
        return res.status(400).json({ error: 'É necessário aceitar o uso dos seus dados (LGPD) para criar a conta.' });
    }

    const emailNormalized = String(email).trim().toLowerCase();
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(emailNormalized);
    if (existing) {
        return res.status(409).json({ error: 'Já existe uma conta com esse email.' });
    }

    const passwordHash = bcrypt.hashSync(password, 10);
    const result = db.prepare(`
        INSERT INTO users (name, email, password_hash, lgpd_consent, consent_at)
        VALUES (?, ?, ?, 1, datetime('now'))
    `).run(name.trim(), emailNormalized, passwordHash);

    const user = { id: result.lastInsertRowid, name: name.trim(), email: emailNormalized };
    const token = generateToken(user);
    res.status(201).json({ token, user });
});

// POST /api/auth/login - autentica e retorna um token
app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ error: 'Preencha email e senha.' });
    }

    const emailNormalized = String(email).trim().toLowerCase();
    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(emailNormalized);
    if (!row || !bcrypt.compareSync(password, row.password_hash)) {
        return res.status(401).json({ error: 'Email ou senha incorretos.' });
    }

    const user = { id: row.id, name: row.name, email: row.email };
    const token = generateToken(user);
    res.json({ token, user });
});

// GET /api/auth/me - retorna os dados do usuário logado (valida o token)
app.get('/api/auth/me', requireAuth, (req, res) => {
    res.json({ user: req.user });
});

// ================================================================
//  BUILDS - PCs salvos por cada usuário logado
// ================================================================

// GET /api/builds - lista os PCs salvos do usuário logado
app.get('/api/builds', requireAuth, (req, res) => {
    const rows = db.prepare(`
        SELECT * FROM builds WHERE user_id = ? ORDER BY created_at DESC
    `).all(req.user.id);

    res.json(rows.map(row => ({
        id: row.id,
        label: row.label,
        budget: row.budget,
        purpose: row.purpose,
        total: row.total,
        components: JSON.parse(row.components),
        createdAt: row.created_at,
    })));
});

// POST /api/builds - salva um PC gerado para o usuário logado
app.post('/api/builds', requireAuth, (req, res) => {
    const { label, budget, purpose, total, components } = req.body;
    if (!budget || !total || !components) {
        return res.status(400).json({ error: 'Campos obrigatórios: budget, total, components.' });
    }

    const result = db.prepare(`
        INSERT INTO builds (user_id, label, budget, purpose, total, components)
        VALUES (?, ?, ?, ?, ?, ?)
    `).run(
        req.user.id,
        label || `PC de R$ ${total}`,
        budget,
        purpose || null,
        total,
        JSON.stringify(components)
    );

    res.status(201).json({ id: result.lastInsertRowid });
});

// DELETE /api/builds/:id - remove um PC salvo (só o dono pode apagar)
app.delete('/api/builds/:id', requireAuth, (req, res) => {
    const result = db.prepare(`
        DELETE FROM builds WHERE id = ? AND user_id = ?
    `).run(req.params.id, req.user.id);

    if (result.changes === 0) return res.status(404).json({ error: 'PC salvo não encontrado.' });
    res.status(204).send();
});

// GET /api/parts - todas as peças, agrupadas por categoria
// (mesmo formato que window.DATABASE tinha no front antigo)
app.get('/api/parts', (req, res) => {
    const rows = db.prepare('SELECT * FROM parts ORDER BY category, id').all();
    const grouped = {};
    for (const cat of CATEGORIES) grouped[cat] = [];
    for (const row of rows) {
        if (!grouped[row.category]) grouped[row.category] = [];
        grouped[row.category].push(rowToPart(row));
    }
    res.json(grouped);
});

// GET /api/parts/:category - peças de uma categoria específica
app.get('/api/parts/:category', (req, res) => {
    const { category } = req.params;
    if (!CATEGORIES.includes(category)) {
        return res.status(404).json({ error: `Categoria "${category}" não existe.` });
    }
    const rows = db.prepare('SELECT * FROM parts WHERE category = ? ORDER BY id').all(category);
    res.json(rows.map(rowToPart));
});

// GET /api/parts/:category/:id - uma peça específica
app.get('/api/parts/:category/:id', (req, res) => {
    const { category, id } = req.params;
    const row = db.prepare('SELECT * FROM parts WHERE category = ? AND id = ?').get(category, id);
    if (!row) return res.status(404).json({ error: 'Peça não encontrada.' });
    res.json(rowToPart(row));
});

// POST /api/parts/:category - cria uma nova peça na categoria
app.post('/api/parts/:category', (req, res) => {
    const { category } = req.params;
    if (!CATEGORIES.includes(category)) {
        return res.status(404).json({ error: `Categoria "${category}" não existe.` });
    }
    const { id, name, price, ...rest } = req.body;
    if (!id || !name || typeof price !== 'number') {
        return res.status(400).json({ error: 'Campos obrigatórios: id, name, price (número).' });
    }
    try {
        db.prepare(`
            INSERT INTO parts (id, category, name, price, extra)
            VALUES (?, ?, ?, ?, ?)
        `).run(id, category, name, price, JSON.stringify(rest));
        res.status(201).json({ id, category, name, price, ...rest });
    } catch (err) {
        if (String(err).includes('UNIQUE')) {
            return res.status(409).json({ error: `Já existe uma peça com id "${id}".` });
        }
        res.status(500).json({ error: 'Erro ao salvar peça.' });
    }
});

// PUT /api/parts/:category/:id - atualiza uma peça existente
app.put('/api/parts/:category/:id', (req, res) => {
    const { category, id } = req.params;
    const existing = db.prepare('SELECT * FROM parts WHERE category = ? AND id = ?').get(category, id);
    if (!existing) return res.status(404).json({ error: 'Peça não encontrada.' });

    const current = rowToPart(existing);
    const { id: _ignoredId, ...updates } = req.body;
    const merged = { ...current, ...updates };
    const { name, price, ...rest } = merged;

    db.prepare(`
        UPDATE parts SET name = ?, price = ?, extra = ?, updated_at = datetime('now')
        WHERE category = ? AND id = ?
    `).run(name, price, JSON.stringify(rest), category, id);

    res.json({ id, category, name, price, ...rest });
});

// DELETE /api/parts/:category/:id - remove uma peça
app.delete('/api/parts/:category/:id', (req, res) => {
    const { category, id } = req.params;
    const result = db.prepare('DELETE FROM parts WHERE category = ? AND id = ?').run(category, id);
    if (result.changes === 0) return res.status(404).json({ error: 'Peça não encontrada.' });
    res.status(204).send();
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`TCR_ASSEMBLER backend rodando em http://localhost:${PORT}`);
});
