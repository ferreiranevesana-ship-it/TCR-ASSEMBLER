# TCR_ASSEMBLER

MVP desenvolvido para o **Trabalho Trimestral Interdisciplinar de Inovação e Front-End**.

O TCR_ASSEMBLER é um portal onde o usuário informa um orçamento e a finalidade
do computador (estudo, programação, jogos, design ou uso geral) e recebe uma
configuração de PC gerada automaticamente — com CPU, GPU, placa-mãe, RAM e
fonte compatíveis entre si e balanceados dentro do valor informado. Usuários
cadastrados podem salvar os PCs gerados e consultá-los depois em um painel
pessoal ("Meus PCs salvos").

## Squad / Equipe

> _Preencher com os nomes dos integrantes da equipe._

## Link de produção

> _Preencher com o link do deploy (Vercel / GitHub Pages) depois de publicado._

## Tecnologias utilizadas

**Front-end**
- HTML5 semântico (`header`, `nav`, `main`, `section`, `article`, `footer`)
- CSS3 (variáveis de cor, Flexbox, CSS Grid, media queries, `box-shadow`,
  `opacity`, pseudo-classes, animações)
- Google Fonts (Inter)
- JavaScript puro (sem frameworks), consumindo a API do back-end via `fetch`

**Back-end**
- Node.js + Express (API REST)
- SQLite (`better-sqlite3`) como banco de dados
- Autenticação com `bcryptjs` (hash de senha) e `jsonwebtoken` (sessão)

## Estrutura do repositório

```
.
├── backend/            → API REST + banco de dados (Node.js + Express + SQLite)
│   ├── src/
│   │   ├── server.js   → rotas da API
│   │   ├── db.js       → conexão e schema do banco
│   │   ├── auth.js     → geração/validação de token (JWT)
│   │   └── seed.js     → popula o banco com as peças iniciais
│   ├── data/            → arquivo do banco SQLite (gerado pelo seed)
│   └── package.json
│
└── frontend/            → interface (o que é publicado no GitHub Pages / Vercel)
    ├── index.html
    ├── style.css
    ├── script.js
    ├── database.js     → fallback local, usado só se a API estiver fora do ar
    └── assets/          → logo e ilustração (SVG)
```

## Funcionalidades

- **Cadastro e login** de usuário, com aceite obrigatório de uso de dados
  (LGPD) no cadastro.
- **Geração automática de PC** dentro do orçamento informado, respeitando
  compatibilidade entre peças (socket, tipo de memória, potência da fonte
  etc.) e limites de preço por finalidade.
- **Meus PCs salvos**: usuários logados podem salvar as configurações
  geradas e visualizá-las depois em um painel (dashboard).
- **Seção demonstrativa de IA**: cards estáticos explicando, com exemplos,
  como o mecanismo de recomendação de peças raciocina (recomendação por
  finalidade, checagem de compatibilidade, balanceamento de orçamento e
  estimativa de performance).
- Layout **responsivo** (desktop, tablet e smartphone) e cuidados básicos de
  **acessibilidade** (`alt` em imagens, contraste, foco visível no teclado,
  navegação por âncoras).

## Privacidade e LGPD

O cadastro só é concluído se o usuário marcar o consentimento de uso de
dados. São armazenados apenas nome, email, senha (com hash, nunca em texto
puro) e os PCs que o próprio usuário escolher salvar. Nenhum dado é
compartilhado com terceiros.

## Como rodar localmente

### 1. Back-end (API)

```bash
cd backend
npm install
npm run seed     # popula o banco com as peças (rodar 1x)
npm start        # inicia a API em http://localhost:3001
```

### 2. Front-end

Em outro terminal:

```bash
cd frontend
python3 -m http.server 8080
```

Acesse **http://localhost:8080**. Por padrão o front aponta para
`http://localhost:3001/api`. Para apontar para uma API em produção, defina
antes de carregar `script.js`:

```html
<script>window.TCR_API_URL = 'https://sua-api-em-producao.com/api';</script>
<script src="script.js"></script>
```

## Publicando (deploy)

- **Front-end** (`frontend/`): GitHub Pages ou Vercel — é só apontar para essa
  pasta como raiz do site estático.
- **Back-end** (`backend/`): precisa de um serviço que rode Node.js (ex:
  Render, Railway, Fly.io). GitHub Pages **não** hospeda o back-end, pois ele
  não roda servidores — só arquivos estáticos.
- Depois de publicar o back-end, atualize `window.TCR_API_URL` no
  `index.html` do front com a URL pública da API.

## Documentação da API

| Método | Rota | Auth | Descrição |
|--------|------|------|-----------|
| GET | `/api/health` | Não | Checagem de saúde |
| GET | `/api/parts` | Não | Todas as peças, agrupadas por categoria |
| GET | `/api/parts/:category` | Não | Peças de uma categoria |
| POST/PUT/DELETE | `/api/parts/:category(/:id)` | Não | Gerenciar peças |
| POST | `/api/auth/register` | Não | Cria conta (`name`, `email`, `password`, `lgpdConsent`) |
| POST | `/api/auth/login` | Não | Login (`email`, `password`) → retorna `token` |
| GET | `/api/auth/me` | Sim | Dados do usuário logado |
| GET | `/api/builds` | Sim | Lista os PCs salvos do usuário logado |
| POST | `/api/builds` | Sim | Salva um PC gerado |
| DELETE | `/api/builds/:id` | Sim | Remove um PC salvo |

Rotas com "Auth: Sim" exigem o header `Authorization: Bearer <token>`
retornado pelo login/cadastro.
